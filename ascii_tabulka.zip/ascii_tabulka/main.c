#include <stdio.h>

#define START 16
#define END 128
#define COLUMN 4

int main(void) {
    int count;
    int sign;

    count = 0;
    printf("----------------ASCII----------------\n");
    printf("-------------------------------------\n");
    for (sign = START; sign <= END; sign++) {
        printf("%4d %c", sign, sign);
        count++;
        if (count % COLUMN == 0) {
            printf("\n");
        }
    }
    return 0;
}
