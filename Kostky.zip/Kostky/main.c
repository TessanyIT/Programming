#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MIN 1
#define MAX 6

#define MIN1 0
#define MAX2 36

int main(void) {
    srand((unsigned) time(NULL));
    int characters1;
    int characters2;
    int characters3;
    int characters4;
    int characters5;
    int characters6;
    int characters7;
    int characters8;
    int question;
    int question2;
    int randomNumber1;
    int randomNumber2;
    int playerNumber;
    char randomShit1;
    char randomShit2;
    int picoNevim;
    int winStreak;
    int money;
    int money2;
    int bet;
    int bet2;
    int betDouble;
    int rouletteOrDice;

    winStreak = 0;
    printf("Hello do you want to play dice or roulette?\n");
    printf("Type 1/ROULETTE 0/DICE\n");
    scanf("%d", &rouletteOrDice);
    while (getchar() != '\n') {
        characters6++;
    }

     if (rouletteOrDice == 1) {
            printf("Okay so you want to play roulette.\n");
            printf("Do you know how to play roulette? 1/YES 0/NO.\n");
            scanf("%d", &question2);
            characters7 = 0;
            while (getchar() != '\n') {
                characters7++;
            }
            if (characters7 != 0) {
            printf("Thats not a 0 or 1 you fucking idiot...\n");
            return 0;
        }
            else if (question2 == 0) {
                printf("Roulette is a game where players place bets on specific numbers, colors, or ranges on a spinning wheel with numbered pockets; once all bets are made, a small ball is spun around the wheel, and players win if the ball lands in a pocket that matches their bet.\n");
                printf("In roulette, players can place bets directly on individual numbers, pairs, rows, or groups of numbers on the inside of the betting table for higher payouts, or on broader categories like red or black, odd or even, and high or low numbers on the outside of the betting table for lower but safer payouts.\n");
                printf("There are 37 sockets for numbers (0-36).\n");
            }
            else if (question2 == 1) {
                printf("Okay good!\n");
            }
        printf("Your budget when starting is 100Kc\n");
        money2 = 100;
        printf("Lets start the game!\n");
        printf("Where do you want to bet? Type a number from 0 to 36. Or e/EVEN and o/ODD\n");
        scanf("%d", &bet2);
        while (getchar() != '\n') {
            characters8++;
        }
        if (characters8 != 0) {
            printf("Bro are you mentally disabled?\n");
            return 0;
        }
        else if (bet2 > 0 && bet2 < 36) {
            printf("So you chose a number.\n");
        }

    }
    else if (rouletteOrDice == 0) {
        printf("Okay so you want to play dice.\n");
        printf("Hello! Do you know how to play dice?. 1/YES 0/NO.\n");
    scanf("%d", &question);
    characters1 = 0;
    money = 0;

    while (getchar() != '\n') {
        characters1++;
    }

    if (question == 0) {
        printf("Okay so the game dice a is a really simple game. The computer starts first with rolling the dice.\nAfter that you roll a dice, and if the number you rolled is higher than the number the computer rolled you WIN and get double your money!\nIf not you lose what you bet.\n");
    } else if (characters1 != 0) {
        printf("You entered something else than a number you fucking idiot. Other not characters: %d.\n", characters1);
        return 0;
    } else if (question == 1) {
        printf("Okay good!\n");
    } else {
        return 0;
    }
    printf("Your budget when starting is 100Kc\n");
    money = 100;
    printf("Lets start the game!\n");
    do {
        characters4 = 0;
        bet = 0;
        randomNumber1 = rand() % MAX + 1;
        randomNumber2 = rand() % MAX + 1;
        printf("The computer starts first with rolling the dice.\n");
        do {
            printf("Plese type the money you want to bet.\n");
            scanf("%d", &bet);
            while (getchar() != '\n') {
                characters4++;
            }
            if (characters4 > 0) {
                printf("Thats not a number you fucking idiot. Try again...\n");
            } else if (bet > money) {
                printf("You dont have enough money to bet that much. Please bet again.\n");
            }
        } while (characters4 > 0 & characters4 < 500 & bet < money);

        printf("Okay so you want to bet: %dKc\n", bet);
        printf("If you want to start please press any key!\n");
        scanf("%c", &randomShit1);


        if (randomNumber1 == 1) {
            printf("+---------+\n");
            printf("|         |\n");
            printf("|    *    |\n");
            printf("|         |\n");
            printf("+---------+\n");
        } else if (randomNumber1 == 2) {
            printf("+---------+\n");
            printf("| *       |\n");
            printf("|         |\n");
            printf("|       * |\n");
            printf("+---------+\n");
        } else if (randomNumber1 == 3) {
            printf("+---------+\n");
            printf("| *       |\n");
            printf("|    *    |\n");
            printf("|       * |\n");
            printf("+---------+\n");
        } else if (randomNumber1 == 4) {
            printf("+---------+\n");
            printf("| *     * |\n");
            printf("|         |\n");
            printf("| *     * |\n");
            printf("+---------+\n");
        } else if (randomNumber1 == 5) {
            printf("+---------+\n");
            printf("| *     * |\n");
            printf("|    *    |\n");
            printf("| *     * |\n");
            printf("+---------+\n");
        } else if (randomNumber1 == 6) {
            printf("+---------+\n");
            printf("| *     * |\n");
            printf("| *     * |\n");
            printf("| *     * |\n");
            printf("+---------+\n");
        }
        printf("The computer rolled number %d!\n", randomNumber1);
        do {
            printf("Do you want to double your bet? 1/YES 0/NO\n");
            scanf("%d", &betDouble);
            characters5 = 0;
            while (getchar() != '\n') {
                characters5++;
            }
            if (betDouble == 1) {
                bet = bet * 2;
                printf("Okay so you bet: %dKc!\n", bet);
            } else if (betDouble == 0) {
                printf("Okay your bet stays the same.\n");
            } else if (characters5 != 0) {
                printf("Please type 1 or 0...\n");
            }
        } while (characters5 != 0);

        printf("Now its your turn! Please press any key.\n");
        scanf("%c", &randomShit2);
        if (randomNumber2 == 1) {
            printf("+---------+\n");
            printf("|         |\n");
            printf("|    *    |\n");
            printf("|         |\n");
            printf("+---------+\n");
        } else if (randomNumber2 == 2) {
            printf("+---------+\n");
            printf("| *       |\n");
            printf("|         |\n");
            printf("|       * |\n");
            printf("+---------+\n");
        } else if (randomNumber2 == 3) {
            printf("+---------+\n");
            printf("| *       |\n");
            printf("|    *    |\n");
            printf("|       * |\n");
            printf("+---------+\n");
        } else if (randomNumber2 == 4) {
            printf("+---------+\n");
            printf("| *     * |\n");
            printf("|         |\n");
            printf("| *     * |\n");
            printf("+---------+\n");
        } else if (randomNumber2 == 5) {
            printf("+---------+\n");
            printf("| *     * |\n");
            printf("|    *    |\n");
            printf("| *     * |\n");
            printf("+---------+\n");
        } else if (randomNumber2 == 6) {
            printf("+---------+\n");
            printf("| *     * |\n");
            printf("| *     * |\n");
            printf("| *     * |\n");
            printf("+---------+\n");
        }

        picoNevim = 0;
        characters3 = 0;

        if (randomNumber1 < randomNumber2) {
            money = bet * 2;
            winStreak++;
            printf("You win! Congratulations! Your win streak is: %d.\n", winStreak);
            printf("Your current budget is: %dKc\n", money);
            printf("Do you want to play again? 1/YES 0/NO\n");
            scanf("%d", &characters3);
            while (getchar() != '\n') {
                characters3++;
            }
            if (money <= 0) {
                printf("Looks like you are out of money huh?\n");
                printf("Well game over for you my friend try next time.");
                return 0;
            }
        } else if (randomNumber1 > randomNumber2) {
            money = money - bet;
            printf("You lose! The computer wins. Your win streak was: %d.\n", winStreak);
            printf("Your current budget is: %dKc\n", money);
            printf("Do you want to play again? 1/YES 0/NO\n");
            scanf("%d", &characters3);
            winStreak = 0;
            while (getchar() != '\n') {
                characters3++;
            }
            if (money <= 0) {
                printf("Looks like you are out of money huh?\n");
                printf("Well game over for you my friend try next time.\n");
                return 0;
            }
        } else if (randomNumber1 == randomNumber2) {
            printf("You rolled the same number as the computer.\n");
            printf("Your current budget is: %dKc\n", money);
            printf("Do you want to play again? 1/YES 0/NO\n");
            scanf("%d", &characters3);
            winStreak = 0;
            while (getchar() != '\n') {
                characters3++;
            }
            if (money <= 0) {
                printf("Looks like you are out of money huh?\n");
                printf("Well game over for you my friend try next time.");
                return 0;
            }
        }
    } while (characters3 != 0);
    }
    else if (characters6 != 0) {
        printf("You are supposed to fucking choose... Nah man fuck you.\n");
        return 0;
    }




    return 0;
}
