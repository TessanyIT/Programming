#include <stdio.h>

#define MIN 10
#define MAX 30

int main(void) {
    int number;
    int characters;
    int playAgain;

    do {
        do {
            printf("Hello please input a number in the interval %d and %d.\n", MIN, MAX);
            characters = 0;
            scanf("%d", &number);
            while (getchar() != '\n') {
                characters++;
            }
            if (characters != 0) {
                printf("You entered something else than a number. Other not numbers: %d.\n", characters);
                printf("Please try again.\n");
            }
        }while (characters != 0);
        if (number > MIN && number < MAX) {
            printf("The number %d is in the in the interval %d and %d.\n", number, MIN, MAX);
        }
        else {
            printf("The number %d is not in the interval %d and %d.\n", number, MIN, MAX);
        }
        do {
            printf("Do you want to try again? 1/YES 0/NO.\n");
            characters = 0;
            scanf("%d", &playAgain);
            while (getchar() != '\n') {
                characters++;
            }
            if (characters != 0) {
                printf("You entered something else than 1 or 0. Other not numbers: %d.\n", characters);
                printf("Please try again.\n");
            }
        }while (characters != 0);
        if (playAgain == 0) {
            printf("Okay the program will be shut down.\n");
            return 0;
        }
    }while (playAgain == 1);
    return 0;
}
