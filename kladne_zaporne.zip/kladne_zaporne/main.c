#include <stdio.h>

int main(void) {
    int number;
    int playAgain;
    int characters;

    do {
        do {
            printf("Hello, please input a number.\n");
            scanf("%d", &number);
            characters = 0;
            while (getchar() != '\n') {
                characters++;
            }
            if (characters != 0) {
                printf("You dint enter a whole number. Other not number: %d\n", characters);
                printf("Please try again.\n");
            }
        } while (characters != 0);
        if (number < 0) {
            printf("Your number is negative.\n");
        } else if (number > 0) {
            printf("Your number is positive.\n");
        } else {
            printf("Your number is zero.\n");
        }
        do {
            printf("Do you want to do it again? 1/YES 0/NO.\n");
            scanf("%d", &playAgain);
            characters = 0;
            while (getchar() != '\n') {
                characters++;
            }
            if (characters != 0) {
                printf("You dint enter a whole number. Other not number: %d\n", characters);
                printf("Please try again.\n");
            }
        } while (characters != 0);

        if (playAgain == 0) {
            printf("Okay the program will shut down.\n");
            return 0;
        }
    } while (playAgain == 1);

    return 0;
}
