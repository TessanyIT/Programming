#include <stdio.h>

int main(void)
{
    int number;
    int playAgain;
    int characters;
    do {
        do {
            printf("Hello, please input a whole number.\n");
            scanf("%d", &number);
            characters = 0;
            while (getchar() != '\n') {
                characters++;
            }
            if (characters != 0) {
                printf("You didnt enter whole number. Other not numbers: %d", characters);
                printf("Please try again.\n");
            }
        }while (characters != 0);
        if (number == 0) {
            printf("Your number is zero. Its not even or odd.\n");
        }
        else if (number % 2 == 1) {
            printf("Your number is odd.\n");
        }
        else {
            printf("Your number is even.\n");
        }
        do {
            printf("Do you want to try it again? 1/YES 0/NO.\n");
            scanf("%d", &playAgain);
            characters = 0;
            while (getchar() != '\n') {
                characters++;
            }
            if (characters != 0) {
                printf("You didnt enter 1 or 0.\n");
                printf("Please try again.\n");
            }
        }while (characters != 0);
        if (playAgain == 0) {
            printf("Okay the program will be shut down.\n");
            return 0;
        }
    }while (playAgain == 1);
    return 0;
}
