#include <stdio.h>

#define TRIES 3
#define PIN 1234

int main(void) {
    int tries;
    int pin;
    int characters;
    tries = TRIES;
    do {
        do {
            printf("Please enter your PIN.\n");
            printf("You have %d tries left.\n", tries);
            tries--;
            scanf("%d", &pin);
            while (getchar() != '\n') {
                characters++;
            }
            if (characters != 0) {
                printf("Thats not a number. Other not numbers: %d.\n", characters);
                printf("Please try again.\n");
            }
        }while (characters != 0);
        if (pin == PIN) {
            printf("Thats the correct PIN.\n");
        }
        else   {
            printf("Thats the wrong PIN.\n");
            printf("\n");
        }
        if (tries != 0 && pin != PIN) {
            printf("Please try again.\n");
            printf("\n");
        }
        else {
            printf("\n");
            printf("You dont have any tries left. The program will shut down, please try again later.\n");
            return 0;
        }

    }while (tries != 0 || pin != PIN);
    return 0;
}
